/* File: combinations.cpp
 *
 * A program to list off all combinations of a master set.
 */
#include <iostream>
#include <string>
#include "set.h"
#include "vector.h"
using namespace std;

void listCombinationsOf(Set<int> s, int k);

int main() {
	Set<int> masterSet;
	masterSet += 0, 1, 2, 3, 4, 5, 6, 7, 8, 9;
	
	listCombinationsOf(masterSet, masterSet.size());
}

/* Recursively lists off all combinations of k elements from the master
 * set s, under the assumption we've already built up the partial set
 * soFar.
 */
void recListCombinationsOf(Set<int> s, int k, Set<int> soFar) {
	/* Base case 1: If there are no more elements to pick, output
	 * what we have so far.
	 */
	if (k == 0) {
		cout << soFar << endl;
	}
	/* In lecture, we had a base case that did absolutely nothing.
	 * Instead, we can just make our recursive case guarded by the
	 * opposite of that base case.  In particular, we don't want
	 * to do anything at all if we want more elements from the
	 * master set than exist.
	 */
	else if (k <= s.size()) {
		/* Fix some element from the set. */
		int elem = s.first();
		
		/* Option 1: Pick this element.  Then we need k - 1 elements from
		 * the remainder of the set.
		 */
		recListCombinationsOf(s - elem, k - 1, soFar + elem);
		
		/* Option 2: Don't pick this element.  Then we need k elements from
		 * the remainder of the set.
		 */
		recListCombinationsOf(s - elem, k, soFar);
	}
}

void listCombinationsOf(Set<int> s, int k) {
	Set<int> emptySet;
	recListCombinationsOf(s, k, emptySet);
}



