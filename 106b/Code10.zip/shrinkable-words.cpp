/* File: shrinkable-words.cpp
 *
 * A program to list off all shrinkable words in English.
 */
#include <iostream>
#include <string>
#include "lexicon.h"
using namespace std;

/* Given a word, returns whether that word is a shrinkable word. */
bool isShrinkableWord(string word, Lexicon& lex);

const int kMinimumWordLength = 9;

int main() {
	Lexicon words("EnglishWords.dat");
	
	/* Check whether each word in the Lexicon is shrinkable. */
	foreach (string word in words) {
		if (word.length() >= kMinimumWordLength &&
		    isShrinkableWord(word, words)) {
			cout << word << endl;
		}
	}
}

/* Returns whether the given word is a shrinkable word. */
bool isShrinkableWord(string word, Lexicon& lex) {
	/* Base Case 1: If this isn't a word, it can't be shrinkable. */
	if (!lex.contains(word)) return false;
	
	/* Base Case 2: If this word has length one, it is shrinkable. */
	if (word.length() == 1)  return true;
	
	/* Try removing every individual character and see if the result
	 * is shrinkable.
	 */
	for (int i = 0; i < word.length(); i++) {
		if (isShrinkableWord(word.substr(0, i) + word.substr(i + 1),
			                   lex)) {
			return true;                   
		}
	}

	/* If no letter works, the word cannot be shrinkable. */	
	return false;
}








