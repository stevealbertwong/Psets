/* File: subsets.cpp
 *
 * A program to list off all subsets of a master set.
 */
#include <iostream>
#include <string>
#include "set.h"
#include "vector.h"
using namespace std;

Vector<Set<int> > subsetsOf(Set<int> masterSet);

int main() {
	Set<int> masterSet;
	masterSet += 1, 2, 3, 4, 5;
	
	foreach (Set<int> subset in subsetsOf(masterSet)) {
		cout << subset << endl;
	}
}

Vector<Set<int> > subsetsOf(Set<int> masterSet) {
	Vector<Set<int> > result;
	
	/* Base case: The only subset of the empty set is the empty set itself. */
	if (masterSet.isEmpty()) {
		result += masterSet;
		return result;
	}
	/* Recursive step: Pull out a single element and obtain all subsets of
	 * the remaining elements.  All of those subsets are subsets of the
	 * master set, as are all sets formed by taking one of those sets
	 * and adding the original element back in.
	 */
	else {
		int elem = masterSet.first();
		
		foreach (Set<int> subset in subsetsOf(masterSet - elem)) {
			result += subset;
			result += subset + elem;
		}
		return result;
	}
}






