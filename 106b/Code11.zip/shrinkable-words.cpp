/* File: shrinkable-words.cpp
 *
 * A program to list off all shrinkable words in English.
 */
#include <iostream>
#include <string>
#include "lexicon.h"
#include "stack.h"
using namespace std;

/* Given a word, returns whether that word can be shrunk
 * down to one letter, leaving a word at each step.
 */
bool isShrinkableWord(string word, Lexicon& lex,
                      Stack<string>& result);

/* Minimum word length before we consider a word "interesting." */
const int kMinimumWordLength = 9;

int main() {
	Lexicon words("EnglishWords.dat");
	
	foreach (string word in words) {
		Stack<string> path;
	
		if (word.length() >= kMinimumWordLength &&
		    isShrinkableWord(word, words, path)) {
			while (!path.isEmpty()) {
				cout << path.pop() << endl;
			}
		}
	}
}

/* Returns whether the given word can be shrunk down to one
 * letter.
 */
bool isShrinkableWord(string word, Lexicon& lex,
                      Stack<string>& result) {
	/* Base Case 1: If this isn't a word, it can't be a
	 * shrinkable word.
	 */
	if (!lex.contains(word)) return false;
	
	/* Base Case 2: If this word has one letter, it must
	 * be a shrinkable word.
	 */
	if (word.length() == 1) {
		result.push(word);
		return true;
	}
	
	/* Recursive step: Try removing each individual character
	 * from the word.  If at any point this forms a shrinkable
	 * word, we know that the overall word is shrinkable.
	 */
	for (int i = 0; i < word.length(); i++) {
		if (isShrinkableWord(word.substr(0, i) + word.substr(i + 1),
			                   lex, result)) {
			result.push(word);
			return true;                   
		}
	}
	
	/* If no options worked, this word must not be shrinkable. */
	return false;
}








