/*********************************************
 * File: crosswordsgraphics.h
 *
 * Routines to visualize the dense crossword
 * puzzle generation logic.
 */

#ifndef CrosswordsGraphics_Included
#define CrosswordsGraphics_Included

#include "gwindow.h"
#include <string>

/* Sets up the display to draw a grid of the indicated dimensions. */
void initCrosswordGraphics(int numRows, int numCols);

/* Draws the given word in the indicated row. */
void drawWord(std::string word, int row);

#endif
