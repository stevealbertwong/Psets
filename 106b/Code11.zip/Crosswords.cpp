/* File: crosswords.cpp
 *
 * A program to generate dense crosswords.
 */
#include <iostream>
#include <string>
#include "lexicon.h"
#include "grid.h"
#include "console.h"
#include "crosswordsgraphics.h"
using namespace std;

/* Constant controlling how large of a puzzle we're solving. */
const int kPuzzleSize = 5;

/* Tries to find a dense crossword, returning the result it finds. */
bool canMakeCrossword(Grid<char>& solution, Lexicon& words);

/* Prints out a crossword to the console. */
void printCrossword(Grid<char>& crossword);

int main() {
	/* To make things easier to read in the back, make the font size
	 * a lot larger.  We're using a monospace font (Courier New) to
	 * make the grid align nicely.
	 */
	setConsoleFont("Courier New-BOLD-36");
	initCrosswordGraphics(kPuzzleSize, kPuzzleSize);
	
	Lexicon words("EnglishWords.dat");
	Grid<char> crossword(kPuzzleSize, kPuzzleSize);
	
	/* See if we can make a crossword, printing it if we can. */
	if (canMakeCrossword(crossword, words)) {
		printCrossword(crossword);
	} else {
		cout << "No solution found." << endl;
	}
}

/* Utility function to print out a crossword. */
void printCrossword(Grid<char>& crossword) {
	for (int i = 0; i < crossword.numRows(); i++) {
		for (int j = 0; j < crossword.numCols(); j++) {
			cout << crossword[i][j];
		}
		cout << endl;
	}
}

bool partialCrosswordIsLegal(Grid<char>& crossword, Lexicon& words,
                             int maxRowUsed) {
 	for (int col = 0; col < crossword.numCols(); col++) {
 		string prefix;
 		for (int row = 0; row <= maxRowUsed; row++) {
 			prefix += crossword[row][col];
 		}
 		if (!words.containsPrefix(prefix)) return false;
 	}
 	
 	return true;
}

bool recCanMakeCrossword(Grid<char>& solution, Lexicon& words,
                         int row) {
 	if (row >= solution.numRows()) {
 		return true;
 	}
 	
 	foreach (string word in words) {
 		for (int col = 0; col < solution.numCols(); col++) {
 			solution[row][col] = word[col];
 		}
 		drawWord(word, row);
 		
 		if (partialCrosswordIsLegal(solution, words, row) &&
 		    recCanMakeCrossword(solution, words, row + 1)) {
 		   return true;
 		}
 	}
 	
 	drawWord("", row);
 	return false;        
}

bool canMakeCrossword(Grid<char>& solution, Lexicon& words) {
	Lexicon legalWords;
	foreach (string word in words) {
		if (word.length() == solution.numCols()) {
			legalWords.add(word);
		}
	}

	return recCanMakeCrossword(solution, legalWords, 0);
}










