/* File: CrosswordsGraphics.cpp
 *
 * Graphics routines for the Crosswords program.
 */
#include <iostream>
#include <string>
#include <memory> // For std::auto_ptr
#include <vector>
#include "grid.h"
#include "gwindow.h"
#include "gobjects.h"
using namespace std;

/* Constants controlling window size. */
const double kWindowWidth  = 400;
const double kWindowHeight = 300;

/* Color of an unselected box. */
const string kNotSelectedColor = "white";

/* Font type. */
const string kFontType = "Courier New";

/* Color of the letters. */
const string kLetterColor = "blue";

static struct {
	/* The window object. */
	auto_ptr<GWindow> window;
	
	/* Master list of labels. */
	vector<GLabel*> labels;
	
	/* Layout information: size of a block (which is always
	 * a square), along with the starting x and y positions
	 * in which everything should fit.
	 */
	double blockSize;
	double startX, startY;
	
	int numRows, numCols;
} cg;

/* Computes geometric information about the window. */
void computeGeometry(int numRows, int numCols) {	
	/* Determine how big a block will be. */
	cg.blockSize = min(cg.window->getWidth() / numCols, cg.window->getHeight() / numRows);
	
	/* Based on this, determine how much padding will be needed. */
	double xPadding = cg.window->getWidth()  - numCols * cg.blockSize;
	double yPadding = cg.window->getHeight() - numRows * cg.blockSize;
	cg.startX = xPadding / 2.0;
	cg.startY = yPadding / 2.0;
}

/* Adds the blocks to the display, along with the (blank) labels
 * for each letter.
 */
void addBlocks(int numRows, int numCols) {
	/* Create the backing labels. */
	cg.labels.resize(numRows);
	for (int i = 0; i < numRows; i++) {
		/* We are assuming the font is a monospace font, so we actually can position
		 * these letters now.
		 */
		cg.labels[i] = new GLabel(string(numCols, ' '));
		cg.labels[i]->setFont(kFontType + "-BOLD-" + integerToString(int(cg.blockSize)));
		
		/* Position the label in the center of its square. */
		double x = cg.startX + (cg.blockSize * numCols - cg.labels[i]->getWidth()) / 2.0;
	
		/* Positioning the y is harder because the text draws on the baseline. */
		double y = cg.startY + (i + 1) * cg.blockSize - cg.labels[i]->getFontDescent();
		cg.labels[i]->setLocation(x, y);
			
		cg.labels[i]->setColor(kLetterColor);
	}
}

void initCrosswordGraphics(int numRows, int numCols) {
	/* Validate input. */
	if (numRows < 0 || numCols < 0) {
		error("Invalid number of rows or columns.");
	}
	
	cg.numRows = numRows;
	cg.numCols = numCols;

	/* Set up the window. */
	cg.window.reset(new GWindow(kWindowWidth, kWindowHeight));

	/* Compute geometry information about where everything goes. */
	computeGeometry(numRows, numCols);
	
	/* Add the blocks and (currently empty) labels. */
	addBlocks(numRows, numCols);
	
	/* Set up future draw operations by setting the color to white. */
	cg.window->setColor("white");
}

void drawWord(string word, int row) {
	if (row < 0 || row >= cg.numRows) {
		error("Out of bounds!");
	}
	
	/* Clear out the old label. */
	cg.window->fillRect(cg.startX, cg.startY + cg.blockSize * row,
	                    cg.blockSize * cg.numCols, cg.blockSize);
	/* Redraw the label. */
	cg.labels[row]->setLabel(word);
	cg.window->draw(cg.labels[row]);
}

