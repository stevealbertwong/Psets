/* File: subsets.cpp
 *
 * A program to list off all subsets of a master set.
 */
#include <iostream>
#include <string>
#include "set.h"
#include "vector.h"
using namespace std;

/* Function to produce a Vector of all the subsets of the master
 * set of integers.
 */
Vector<Set<int> > subsetsOf(Set<int> masterSet);

/* Function to list, but not return, all subsets of the master set. */
void listSubsetsOf(Set<int> masterSet);

int main() {
	Set<int> masterSet;
	masterSet += 1, 2, 3, 4, 5;
	
	listSubsetsOf(masterSet);
}

Vector<Set<int> > subsetsOf(Set<int> masterSet) {
	Vector<Set<int> > result;
	
	/* Base case: The only subset of the empty set is the empty set itself. */
	if (masterSet.isEmpty()) {
		result += masterSet;
		return result;
	}
	/* Recursive step: Pull out a single element and obtain all subsets of
	 * the remaining elements.  All of those subsets are subsets of the
	 * master set, as are all sets formed by taking one of those sets
	 * and adding the original element back in.
	 */
	else {
		int elem = masterSet.first();
		
		foreach (Set<int> subset in subsetsOf(masterSet - elem)) {
			result += subset;
			result += subset + elem;
		}
		return result;
	}
}

/* Function that lists, but does not return, all subsets of the string. */
void recListSubsetsOf(Set<int> masterSet, Set<int> soFar) {
	/* Base case: If there are no integers left in the set,
	 * the set we've built up so far must be the set we've
	 * created.
	 */
	if (masterSet.isEmpty()) {
		cout << soFar << endl;
	}
	/* Otherwise, try two options: either don't include the current
	 * element, or do include the current element.
	 */
	else {
		int elem = masterSet.first();
		recListSubsetsOf(masterSet - elem, soFar);
		recListSubsetsOf(masterSet - elem, soFar + elem);
	}
}

void listSubsetsOf(Set<int> masterSet) {
	Set<int> soFar;
	recListSubsetsOf(masterSet, soFar);
}



